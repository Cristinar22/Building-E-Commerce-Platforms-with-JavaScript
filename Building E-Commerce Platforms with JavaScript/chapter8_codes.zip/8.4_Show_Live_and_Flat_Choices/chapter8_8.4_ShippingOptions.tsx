import React from 'react';

function ShippingOptions({ rates }) {
  return (
    <div>
      <h3>Select shipping</h3>
      <label>
        <input type="radio" name="shipping" value="flat" /> Flat Rate: ₦2,000
      </label>
      {rates.map((rate) => (
        <label key={rate.object_id}>
          <input type="radio" name="shipping" value={rate.amount} />
          {rate.provider} ({rate.servicelevel.name}): ₦{rate.amount}
        </label>
      ))}
    </div>
  );
}

export default ShippingOptions;