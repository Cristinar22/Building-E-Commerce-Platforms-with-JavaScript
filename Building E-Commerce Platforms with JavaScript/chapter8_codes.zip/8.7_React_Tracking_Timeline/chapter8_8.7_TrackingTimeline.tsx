import { Box, Flex, Text, VStack } from '@chakra-ui/react';

function TrackingTimeline({ updates }) {
  return (
    <VStack spacing={4} align="stretch">
      {updates.map((step, idx) => (
        <Flex key={idx} align="center">
          <Box w={3} h={3} bg="brand.500" borderRadius="full" mr={3} />
          <Box>
            <Text fontWeight="bold">{step.status}</Text>
            <Text fontSize="sm">{step.details}</Text>
            <Text fontSize="xs" color="gray.500">{step.timestamp}</Text>
          </Box>
        </Flex>
      ))}
    </VStack>
  );
}

export default TrackingTimeline;