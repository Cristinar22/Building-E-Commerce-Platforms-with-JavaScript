// pages/api/shipping-rates.js
import shippoLib from 'shippo';

const shippo = shippoLib(process.env.SHIPPO_API_KEY);

export default async function handler(req, res) {
  // Example: dummy cart shipping from Lagos to London
  const { addressTo, addressFrom, parcel } = req.body;

  try {
    // 1. Create shipment
    const shipment = await shippo.shipment.create({
      address_from: addressFrom,
      address_to: addressTo,
      parcels: [parcel],
      async: false
    });

    // 2. Return the list of available rates
    res.status(200).json({ rates: shipment.rates });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}