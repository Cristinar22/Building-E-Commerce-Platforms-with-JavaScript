// Purchase the label
const transaction = await shippo.transaction.create({
  shipment: shipment.object_id,
  rate: shipment.rates[0].object_id,
  label_file_type: "PDF",
  async: false
});