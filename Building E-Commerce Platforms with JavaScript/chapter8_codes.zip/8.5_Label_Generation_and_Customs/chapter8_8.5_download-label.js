// Download the label PDF
const labelUrl = transaction.label_url;
// Save or email this to your warehouse or the customer!