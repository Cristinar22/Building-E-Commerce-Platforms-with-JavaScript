// Generate shipment with customs declaration
const shipment = await shippo.shipment.create({
  address_from: { /* ... */ },
  address_to: { /* ... */ },
  parcels: [ /* ... */ ],
  customs_declaration: {
    contents_type: "MERCHANDISE",
    contents_explanation: "Skincare set",
    non_delivery_option: "RETURN",
    certify: true,
    certify_signer: "Shop Owner",
    eel_pfc: "NOEEI 30.37(a)", // Export code
    items: [
      {
        description: "Lavender Body Butter",
        quantity: 1,
        net_weight: "0.5",
        mass_unit: "kg",
        value_amount: "20",
        value_currency: "USD",
        origin_country: "NG",
        tariff_number: "3304.99.10"
      }
    ]
  }
});