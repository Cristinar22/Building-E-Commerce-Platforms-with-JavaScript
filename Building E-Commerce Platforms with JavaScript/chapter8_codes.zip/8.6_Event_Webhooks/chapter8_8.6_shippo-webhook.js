// pages/api/shippo-webhook.js
export default async function handler(req, res) {
  const event = req.body;

  if (event.event === "track_updated") {
    const { tracking_status, tracking_number, carrier } = event.data;

    // Save new status in your DB
    await updateShipmentStatus(tracking_number, tracking_status.status, tracking_status.status_details);

    // If delivered, email customer!
    if (tracking_status.status === "DELIVERED") {
      await sendDeliveryEmail(event.data.recipient_email, tracking_number, carrier);
    }
  }

  res.status(200).json({ received: true });
}