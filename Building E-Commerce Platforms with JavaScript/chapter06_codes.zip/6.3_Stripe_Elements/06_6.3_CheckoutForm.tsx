// packages/web/src/components/CheckoutForm.tsx
import { CardElement, useStripe, useElements } from '@stripe/react-stripe-js'
import { useState } from 'react'

export function CheckoutForm({ amount }) {
  const stripe = useStripe()
  const elements = useElements()
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    const { clientSecret } = await fetch('/api/create-payment-intent', {
      method: 'POST',
      body: JSON.stringify({ amount, currency: 'usd' }),
      headers: { 'Content-Type': 'application/json' }
    }).then(res => res.json())

    const result = await stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: elements.getElement(CardElement)
      }
    })

    if (result.error) setError(result.error.message)
    else if (result.paymentIntent.status === 'succeeded') setSuccess(true)
  }

  return (
    <form onSubmit={handleSubmit}>
      <CardElement />
      <button type="submit" disabled={!stripe}>Pay</button>
      {error && <div>{error}</div>}
      {success && <div>Payment succeeded!</div>}
    </form>
  )
}