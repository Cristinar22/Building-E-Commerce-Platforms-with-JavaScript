// pages/api/create-payment-intent.ts
import Stripe from 'stripe'

const stripe = new Stripe(process.env.STRIPE_SECRET!, { apiVersion: '2023-10-16' })

export default async function handler(req, res) {
  const { amount, currency } = req.body
  const paymentIntent = await stripe.paymentIntents.create({
    amount,
    currency,
    automatic_payment_methods: { enabled: true }
  })
  res.status(200).json({ clientSecret: paymentIntent.client_secret })
}