const paymentIntent = await stripe.paymentIntents.create({
  amount,
  currency,
  automatic_payment_methods: { enabled: true },
  customer: customerId,
  shipping: {
    name: 'Jane Doe',
    address: {
      line1: '123 Market St',
      city: 'San Francisco',
      state: 'CA',
      postal_code: '94103',
      country: 'US'
    }
  },
  automatic_tax: { enabled: true }
})