import { FlutterWaveButton, closePaymentModal } from 'flutterwave-react-v3'

const config = {
  public_key: process.env.NEXT_PUBLIC_FLUTTERWAVE_KEY!,
  tx_ref: Date.now(),
  amount: 100,
  currency: 'NGN',
  payment_options: 'card,ussd,banktransfer,mpesa',
  customer: {
    email: 'customer@example.com',
    phonenumber: '08012345678',
    name: 'Jane Doe'
  },
  customizations: {
    title: 'Shop Payment',
    description: 'Payment for items in cart',
    logo: '/logo.png'
  }
}

<FlutterWaveButton
  {...config}
  text="Pay with Flutterwave"
  callback={response => {
    console.log(response)
    closePaymentModal()
  }}
  onClose={() => {}}
/>