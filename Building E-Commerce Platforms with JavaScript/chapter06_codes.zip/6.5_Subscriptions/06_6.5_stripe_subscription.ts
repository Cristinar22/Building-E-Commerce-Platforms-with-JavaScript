const customer = await stripe.customers.create({ email: userEmail })
const session = await stripe.checkout.sessions.create({
  payment_method_types: ['card'],
  customer: customer.id,
  line_items: [{ price: 'price_xxxx', quantity: 1 }],
  mode: 'subscription',
  success_url: 'https://yourshop.com/success',
  cancel_url: 'https://yourshop.com/cancel'
})
// Redirect user to session.url