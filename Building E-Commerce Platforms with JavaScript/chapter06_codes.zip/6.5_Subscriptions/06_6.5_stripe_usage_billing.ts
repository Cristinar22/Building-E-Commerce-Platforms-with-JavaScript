await stripe.subscriptionItems.createUsageRecord(
  'si_XXXX', // Subscription item ID
  { quantity: 1, timestamp: Math.floor(Date.now() / 1000), action: 'increment' }
)