await stripe.paymentIntents.create({
  amount,
  currency
}, { idempotencyKey: uniqueOrderId })