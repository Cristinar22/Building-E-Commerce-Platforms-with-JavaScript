#!/bin/bash
npx create-strapi-app@latest pim --quickstart --no-run
cd pim
# Install GraphQL plugin
yarn strapi install graphql
yarn develop
