# Chapter 3 Code Files

This ZIP archive contains all code snippets from Chapter 3, organized by subheading:

- 3.4 Installing Strapi Locally
  - quickstart.sh: Shell script to spin up Strapi quickly.
  - docker-compose.yml: Docker Compose configuration for Strapi & PostgreSQL.

- 3.6 Seeding 40 Sample Items
  - seed.js: Seeder script using Faker to populate sample products.

- 3.8 Generating a Simple GraphQL Query
  - query.graphql: GraphQL query to fetch products with pagination.

Each file name includes the chapter and section number for clarity.
