module.exports = async ({ strapi }) => {
  const faker = (await import('@faker-js/faker')).faker;
  for (let i = 0; i < 40; i++) {
    await strapi.entityService.create('api::product.product', {
      data: {
        title: faker.commerce.productName(),
        description: faker.commerce.productDescription(),
        price: faker.commerce.price({ min: 10, max: 120 }),
        variants: [
          { sku: faker.string.uuid().slice(0, 8), option: '100ml', extra_price: 0, stock: 50 },
          { sku: faker.string.uuid().slice(0, 8), option: '200ml', extra_price: 4, stock: 30 },
        ],
        attributes: [1, 2],
        status: 'active',
      },
    });
  }
};
