import { startRegistration, startAuthentication } from "@passwordless-id/webauthn";

// Registration
await startRegistration({ username: "sarah@gmail.com" });

// Login
await startAuthentication({ username: "sarah@gmail.com" });
