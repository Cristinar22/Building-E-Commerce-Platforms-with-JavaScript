import rateLimit from 'express-rate-limit';

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 min
  max: 10, // limit each IP to 10 requests per windowMs
});
app.use("/api/auth", limiter);
