// After receiving token from frontend
const res = await fetch("https://hcaptcha.com/siteverify", {
  method: "POST",
  body: new URLSearchParams({
    secret: "your-secret-key",
    response: token,
  }),
});
const data = await res.json();
if (!data.success) throw new Error("Bot suspected!");
