pnpm add speakeasy qrcode
