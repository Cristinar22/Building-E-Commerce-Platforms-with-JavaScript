import speakeasy from "speakeasy";
import qrcode from "qrcode";

// Generate secret and QR
const secret = speakeasy.generateSecret();
qrcode.toDataURL(secret.otpauth_url, (err, data_url) => {
  // Display QR to user
});

// To verify
speakeasy.totp.verify({
  secret: secret.base32,
  encoding: "base32",
  token: "123456"
});
