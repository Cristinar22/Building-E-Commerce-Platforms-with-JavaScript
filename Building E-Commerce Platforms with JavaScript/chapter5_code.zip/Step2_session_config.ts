// NextAuth session configuration
export default NextAuth({
  // For session-based:
  session: { strategy: "database" },
  // For JWT-based (scalable):
  // session: { strategy: "jwt" },
  jwt: {
    maxAge: 60 * 60, // 1 hour
    updateAge: 60 * 5, // 5 min
  }
});
