#!/bin/bash
# Chapter 1 - 1.5.2 Scaffold with Turborepo
npx create-turbo@latest my-store
cd my-store
pnpm install
pnpm dev
