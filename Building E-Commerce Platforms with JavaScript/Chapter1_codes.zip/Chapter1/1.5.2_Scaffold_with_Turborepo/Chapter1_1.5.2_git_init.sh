#!/bin/bash
# Chapter 1 - 1.5.2 Scaffold with Turborepo Git Init
git init
git add .
git commit -m "feat: turbo skeleton"
