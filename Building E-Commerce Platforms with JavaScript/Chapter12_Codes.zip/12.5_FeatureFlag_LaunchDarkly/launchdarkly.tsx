import { withLDProvider, useFlags } from 'launchdarkly-react-client-sdk';

function Checkout() {
  const { newCheckoutUi } = useFlags();
  return newCheckoutUi ? <NewCheckoutUI /> : <OldCheckoutUI />;
}

export default withLDProvider({ clientSideID: process.env.LD_CLIENT_ID })(Checkout);