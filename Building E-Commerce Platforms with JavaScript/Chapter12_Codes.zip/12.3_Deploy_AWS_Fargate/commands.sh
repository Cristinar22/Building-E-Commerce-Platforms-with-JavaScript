# AWS CLI & ECS CLI installation (see AWS docs)
# Login & push to ECR
aws configure
aws ecr create-repository --repository-name my-ecommerce
docker tag my-ecommerce:latest <account-id>.dkr.ecr.<region>.amazonaws.com/my-ecommerce:latest
aws ecr get-login-password | docker login --username AWS --password-stdin <your-ecr-url>
docker push <your-ecr-url>/my-ecommerce:latest

# Provision with Terraform/Pulumi (add aws_ecs_cluster and aws_ecs_task_definition as needed)