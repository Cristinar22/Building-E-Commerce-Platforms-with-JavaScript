const aws = require("@pulumi/aws");

const server = new aws.ec2.Instance("web-server", {
    instanceType: "t2.micro",
    ami: "ami-0c55b159cbfafe1f0",
    tags: { Name: "pulumi-demo" }
});

exports.publicIp = server.publicIp;