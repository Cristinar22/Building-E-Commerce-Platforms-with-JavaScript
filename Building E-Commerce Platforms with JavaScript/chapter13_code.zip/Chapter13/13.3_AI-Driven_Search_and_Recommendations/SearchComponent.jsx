import algoliasearch from "algoliasearch/lite";
import { InstantSearch, SearchBox, Hits } from "react-instantsearch-dom";

const searchClient = algoliasearch("APP_ID", "SEARCH_API_KEY");

function Product({ hit }) {
  return (
    <div>
      <img src={hit.image} alt={hit.name} width={100} />
      <div>{hit.name}</div>
      <div>{hit.price} {hit.currency}</div>
    </div>
  );
}

export default function SearchComponent() {
  return (
    <InstantSearch searchClient={searchClient} indexName="products">
      <SearchBox />
      <Hits hitComponent={Product} />
    </InstantSearch>
  );
}
