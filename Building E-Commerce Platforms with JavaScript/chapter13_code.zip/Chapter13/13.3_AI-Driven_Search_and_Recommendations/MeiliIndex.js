const MeiliSearch = require("meilisearch");
const getEmbedding = require("./MeiliEmbedding");

const client = new MeiliSearch({ host: "http://127.0.0.1:7700" });
const index = client.index("products");

async function indexProducts(products) {
  const docs = await Promise.all(products.map(async (p) => ({
    ...p,
    vector: await getEmbedding(p.description),
  })));

  await index.addDocuments(docs);
}

module.exports = indexProducts;
