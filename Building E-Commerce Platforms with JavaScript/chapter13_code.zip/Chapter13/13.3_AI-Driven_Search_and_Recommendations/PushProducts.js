const algoliasearch = require("algoliasearch");
const client = algoliasearch("APP_ID", "ADMIN_API_KEY");
const index = client.initIndex("products");

// Fetch your products from DB
async function fetchProductsFromDB() {
  // ... implement fetch ...
}

async function push() {
  const products = await fetchProductsFromDB();
  await index.saveObjects(products, { autoGenerateObjectIDIfNotExist: true });
}

push();
