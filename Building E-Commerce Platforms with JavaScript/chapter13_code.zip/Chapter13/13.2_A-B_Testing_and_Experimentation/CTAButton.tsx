import { useExperiment } from "@growthbook/growthbook-react";

function CTAButton() {
  const { value } = useExperiment("cta-button-color", { variations: ["blue", "red"] });
  return (
    <button style={{ background: value === "blue" ? "#2196f3" : "#f44336" }}>
      Buy Now
    </button>
  );
}

export default CTAButton;
