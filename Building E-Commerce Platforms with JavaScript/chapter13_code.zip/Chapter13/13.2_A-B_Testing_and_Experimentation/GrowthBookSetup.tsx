import { GrowthBook, GrowthBookProvider } from "@growthbook/growthbook-react";

const growthbook = new GrowthBook({
  apiHost: "https://cdn.growthbook.io",
  clientKey: "YOUR_KEY"
});

function App() {
  return (
    <GrowthBookProvider growthbook={growthbook}>
      <MainApp />
    </GrowthBookProvider>
  );
}

export default App;
