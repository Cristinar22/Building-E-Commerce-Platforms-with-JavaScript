expo init MyFinalApp
