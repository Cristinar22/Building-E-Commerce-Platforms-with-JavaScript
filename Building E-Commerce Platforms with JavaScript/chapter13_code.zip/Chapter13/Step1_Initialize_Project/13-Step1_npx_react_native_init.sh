npx react-native init MyFinalApp
