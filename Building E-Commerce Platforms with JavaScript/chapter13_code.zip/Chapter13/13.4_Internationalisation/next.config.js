module.exports = {
  i18n: {
    locales: ["en", "fr", "ar", "de", "zh"],
    defaultLocale: "en"
  }
};
