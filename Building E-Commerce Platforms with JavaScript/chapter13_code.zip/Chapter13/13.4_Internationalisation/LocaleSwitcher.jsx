import { useRouter } from 'next/router';

export default function LocaleSwitcher() {
  const { locale, push, pathname, query, asPath } = useRouter();
  return (
    <select
      value={locale}
      onChange={e => push({ pathname, query }, asPath, { locale: e.target.value })}
    >
      <option value="en">English</option>
      <option value="fr">Français</option>
      <option value="ar">العربية</option>
      <option value="de">Deutsch</option>
      <option value="zh">中文</option>
    </select>
  );
}
