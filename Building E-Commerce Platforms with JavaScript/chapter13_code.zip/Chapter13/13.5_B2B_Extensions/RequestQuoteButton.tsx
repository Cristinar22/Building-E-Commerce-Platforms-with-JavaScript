import React from 'react';

export default function RequestQuoteButton({ productId }) {
  const openQuoteModal = (id) => {
    // open modal logic
  };

  return (
    <button onClick={() => openQuoteModal(productId)}>
      Request a Quote
    </button>
  );
}
