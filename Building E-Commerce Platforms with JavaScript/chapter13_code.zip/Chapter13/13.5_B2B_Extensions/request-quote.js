export default async function handler(req, res) {
  const { productId, email, quantity } = req.body;
  await db.quote.create({
    data: { productId, email, quantity, status: "pending" }
  });
  // Notify sales team, send auto-reply
  res.status(200).json({ message: "Quote requested!" });
}
