export function getPrice(userType, basePrice) {
  if (userType === "gold") return basePrice * 0.9;
  if (userType === "wholesale") return basePrice * 0.7;
  return basePrice;
}
