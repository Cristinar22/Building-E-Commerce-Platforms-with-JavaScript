// next.config.js
module.exports = {
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          // Content Security Policy (with nonce for inline scripts)
          {
            key: "Content-Security-Policy",
            value:
              "default-src 'self'; script-src 'self' https://js.stripe.com 'nonce-REPLACE_ME'; style-src 'self' 'unsafe-inline'; img-src * data:; connect-src *; frame-src https://js.stripe.com; object-src 'none';",
          },
          // HSTS (1 year, include subdomains, preload)
          { key: "Strict-Transport-Security", value: "max-age=31536000; includeSubDomains; preload" },
          // Referrer-Policy (only send origin when on same domain)
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          // Cross-Origin Policies
          { key: "Cross-Origin-Opener-Policy", value: "same-origin" },
          { key: "Cross-Origin-Embedder-Policy", value: "require-corp" },
        ],
      },
    ];
  },
};