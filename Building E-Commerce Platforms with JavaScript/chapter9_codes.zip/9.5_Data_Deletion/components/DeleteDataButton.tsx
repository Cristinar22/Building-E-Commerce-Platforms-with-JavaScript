// components/DeleteDataButton.tsx
export function DeleteDataButton() {
  const handleDelete = async () => {
    if (!confirm("Are you sure you want to delete all your data? This cannot be undone.")) return;
    await fetch('/api/data-delete', { method: 'DELETE' });
    alert("Your data has been deleted.");
  };

  return (
    <button onClick={handleDelete}>
      Delete My Data
    </button>
  );
}