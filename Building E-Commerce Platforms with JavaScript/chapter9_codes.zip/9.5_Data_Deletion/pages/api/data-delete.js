// pages/api/data-delete.js
import { getSession } from "next-auth/react";

export default async function handler(req, res) {
  const session = await getSession({ req });
  if (!session) return res.status(401).json({ error: "Not authenticated" });

  await db.user.delete({ where: { email: session.user.email } });
  res.status(200).json({ success: true });
}