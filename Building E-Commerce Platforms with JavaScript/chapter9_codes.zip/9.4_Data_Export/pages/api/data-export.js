// pages/api/data-export.js
import { getSession } from "next-auth/react";
import db from "../../lib/db"; // however you connect

export default async function handler(req, res) {
  const session = await getSession({ req });
  if (!session) return res.status(401).json({ error: "Not authenticated" });

  const user = await db.user.findUnique({
    where: { email: session.user.email },
    include: { orders: true, address: true },
  });

  // Filter out sensitive fields (e.g., password hash)
  const { password, ...exportable } = user;

  res.status(200).json(exportable);
}