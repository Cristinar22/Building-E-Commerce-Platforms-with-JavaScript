// components/DownloadDataButton.tsx
import { saveAs } from 'file-saver';

export function DownloadDataButton() {
  return (
    <button onClick={async () => {
      const res = await fetch('/api/data-export');
      const blob = await res.blob();
      saveAs(blob, "my-shop-data.json");
    }}>
      Download My Data
    </button>
  );
}