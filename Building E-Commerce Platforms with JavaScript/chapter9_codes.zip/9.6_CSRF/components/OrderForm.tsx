// components/OrderForm.tsx
import { useCsrfToken } from 'next-csrf';

export function OrderForm() {
  const { csrfToken } = useCsrfToken();

  return (
    <form method="POST" action="/api/order">
      <input type="hidden" name="_csrf" value={csrfToken} />
      <!-- other order fields -->
      <button type="submit">Place Order</button>
    </form>
  );
}