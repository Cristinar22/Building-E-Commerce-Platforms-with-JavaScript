// pages/api/order.js
import { csrf } from "../../lib/csrf";

export default csrf(async function handler(req, res) {
  // Now protected against CSRF attacks!
  // Handle order logic here
  res.status(200).json({ success: true });
});
