async function releasePayout(orderItemId) {
  const orderItem = await prisma.orderItem.findUnique({ where: { id: orderItemId } });
  if (!orderItem) throw new Error("Order item not found");
  if (!orderItem.isShipped) throw new Error("Cannot payout before shipment");

  // Pseudo payment API call
  await paymentGateway.transfer({
    to: orderItem.vendor.paymentAccount,
    amount: orderItem.payout,
    currency: "NGN"
  });

  await prisma.orderItem.update({
    where: { id: orderItemId },
    data: { payoutStatus: "PAID" }
  });
}

module.exports = { releasePayout };