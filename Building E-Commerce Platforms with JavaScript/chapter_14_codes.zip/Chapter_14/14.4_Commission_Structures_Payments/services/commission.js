function calculateCommission(price, commissionRate = 0.1) {
  return price * commissionRate;
}

function processOrderItem(orderItem) {
  const commission = calculateCommission(orderItem.price);
  return {
    ...orderItem,
    commission,
    payout: orderItem.price - commission
  };
}

module.exports = { calculateCommission, processOrderItem };