// pages/api/disputes/create.js
import prisma from '../../../lib/prisma';

export default async function handler(req, res) {
  const { orderItemId, description } = req.body;
  const userId = req.session.user.id;

  const dispute = await prisma.dispute.create({
    data: { orderItemId, userId, description }
  });

  // Notify support staff (email/slack)
  res.status(201).json({ message: "Dispute created", dispute });
}