// pages/admin/vendors.js
import { useState, useEffect } from 'react';

export default function AdminVendors() {
  const [vendors, setVendors] = useState([]);

  useEffect(() => {
    fetch('/api/vendors/pending')
      .then(res => res.json())
      .then(data => setVendors(data));
  }, []);

  const approveVendor = async (id) => {
    await fetch(`/api/vendors/${id}/approve`, { method: 'POST' });
    setVendors(vendors.filter(v => v.id !== id));
  };

  return (
    <div>
      <h1>Pending Vendors</h1>
      {vendors.length === 0 ? <p>No pending vendors</p> :
        vendors.map(v => (
          <div key={v.id}>
            <p>{v.name} - {v.email}</p>
            <button onClick={() => approveVendor(v.id)}>Approve</button>
          </div>
        ))}
    </div>
  );
}