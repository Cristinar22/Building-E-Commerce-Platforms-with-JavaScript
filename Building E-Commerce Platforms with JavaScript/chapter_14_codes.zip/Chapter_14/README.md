# Chapter 14 Code Files

## Structure

- `14.3_Vendor_Registration_Onboarding_Module/`
  - `models/Vendor.prisma`: Prisma schema for the Vendor model.
  - `api/vendors/register.js`: API route for vendor registration.
  - `pages/admin/vendors.js`: React admin interface for approving vendors.
  - `api/vendors/pending.js`: API route to list pending vendors.
  - `api/vendors/[id]/approve.js`: API route to approve a vendor.

- `14.4_Commission_Structures_Payments/`
  - `models/OrderItem.prisma`: Prisma schema extension for commission and payout fields.
  - `services/commission.js`: Functions to calculate commission and process order items.
  - `services/payout.js`: Payout release logic.

- `14.5_Disputes_Support/`
  - `models/Dispute.prisma`: Prisma schema for dispute tickets.
  - `api/disputes/create.js`: API route to create a new dispute.

This zip contains categorized code files for Chapter 14 of the marketplace architecture guide.