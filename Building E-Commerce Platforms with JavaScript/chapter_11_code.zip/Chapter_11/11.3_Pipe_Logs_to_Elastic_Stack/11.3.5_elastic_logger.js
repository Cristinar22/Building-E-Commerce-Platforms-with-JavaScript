const pino = require('pino');
const pinoElastic = require('pino-elasticsearch');
const streamToElastic = pinoElastic({
  index: 'shop-logs',
  node: process.env.ELASTIC_URL, // from Elastic Cloud
  auth: {
    username: process.env.ELASTIC_USER,
    password: process.env.ELASTIC_PASS
  }
});
const logger = pino({}, streamToElastic);
