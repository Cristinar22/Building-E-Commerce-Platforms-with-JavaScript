// Usage in routes
const logger = require('../lib/logger');

logger.info({ user: session.user.email, action: 'checkout', orderId }, "Order checked out");
logger.error({ err, route: 'POST /api/checkout' }, "Checkout failed");
