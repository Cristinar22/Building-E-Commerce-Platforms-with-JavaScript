pnpm add pino
