// Instrumenting checkout spans
const { trace } = require('@opentelemetry/api');

async function checkoutOrder(req, res) {
  const span = trace.getTracer('default').startSpan('checkout');

  try {
    span.addEvent('starting payment');
    await processPayment();
    span.addEvent('updating inventory');
    await updateInventory();
    span.setStatus({ code: 1 }); // success
    res.json({ success: true });
  } catch (err) {
    span.setStatus({ code: 2, message: err.message });
    throw err;
  } finally {
    span.end();
  }
}
