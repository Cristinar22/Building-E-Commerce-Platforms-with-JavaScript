// lib/metrics.js
const client = require('prom-client');
const collectDefaultMetrics = client.collectDefaultMetrics;
collectDefaultMetrics();

const checkoutLatency = new client.Histogram({
  name: 'checkout_latency_seconds',
  help: 'Checkout latency in seconds',
  buckets: [0.1, 0.2, 0.5, 1, 2, 5]
});

function measureCheckout(req, res, next) {
  const end = checkoutLatency.startTimer();
  res.on('finish', () => end());
  next();
}

module.exports = { measureCheckout, client };
