// pages/api/metrics.js
const { client } = require('../../lib/metrics');
export default (req, res) => {
  res.setHeader('Content-Type', client.register.contentType);
  res.end(client.register.metrics());
};
