# Chapter 10 Code Snippets

This archive contains all code snippets from Chapter 10, organized by subheading:

- 10.3 Hands-On 2: getStaticProps.js
- 10.4 Hands-On 3: install_clinic.sh, profile_clinic.sh
- 10.5 Hands-On 4: ImageComponent.tsx, next.config.js
- 10.6 Hands-On 5: spin_up_redis.sh, install_ioredis.sh, products.js
- 10.7 Hands-On 6: install_k6.sh, test.js
