import Image from 'next/image';

<Image
  src="/hero.jpg"
  width={1200}
  height={800}
  alt="Hero product"
  priority // above the fold
/>