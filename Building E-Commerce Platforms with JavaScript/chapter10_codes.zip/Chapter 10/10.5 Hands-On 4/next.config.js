module.exports = {
  images: {
    domains: ['your-cdn.com', 'res.cloudinary.com'],
  },
};