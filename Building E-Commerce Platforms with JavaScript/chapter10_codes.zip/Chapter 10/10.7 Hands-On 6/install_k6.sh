# Install k6
# Visit https://k6.io/ for installation instructions