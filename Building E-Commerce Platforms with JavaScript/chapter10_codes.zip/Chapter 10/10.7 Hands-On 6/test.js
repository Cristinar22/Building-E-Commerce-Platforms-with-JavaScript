import http from 'k6/http';
import { check } from 'k6';

export let options = {
  vus: 200, // virtual users
  duration: '1m',
  thresholds: {
    http_req_duration: ['p(95)<200'], // 95% under 200ms
  },
};

export default function () {
  const res = http.get('https://yourshop.com/api/products');
  check(res, {
    'is status 200': (r) => r.status === 200;
  });
}