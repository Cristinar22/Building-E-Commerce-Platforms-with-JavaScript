clinic doctor -- node server.js
clinic open <reportfile>