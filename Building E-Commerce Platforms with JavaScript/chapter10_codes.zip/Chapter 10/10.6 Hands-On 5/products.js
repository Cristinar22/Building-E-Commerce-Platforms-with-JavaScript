// pages/api/products.js
import Redis from 'ioredis';
const redis = new Redis();

export default async function handler(req, res) {
  const cacheKey = 'products-list-v1';

  // Check cache first
  const cached = await redis.get(cacheKey);
  if (cached) {
    return res.status(200).json(JSON.parse(cached));
  }

  // Otherwise, fetch and cache
  const products = await fetchProductsFromDb();
  await redis.set(cacheKey, JSON.stringify(products), 'EX', 60); // 60 seconds

  res.status(200).json(products);
}