function GiveBackCheckbox({ onChange }) {
  return (
    <label>
      <input type="checkbox" onChange={e => onChange(e.target.checked)} />
      Add ₦100 donation to local charity
    </label>
  );
}