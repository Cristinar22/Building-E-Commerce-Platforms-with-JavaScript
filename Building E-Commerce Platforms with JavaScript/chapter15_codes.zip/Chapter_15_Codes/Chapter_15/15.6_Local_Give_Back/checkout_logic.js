// Extend checkout logic to include donation amount
let totalAmount = cartTotal;
if (donationSelected) totalAmount += 100;