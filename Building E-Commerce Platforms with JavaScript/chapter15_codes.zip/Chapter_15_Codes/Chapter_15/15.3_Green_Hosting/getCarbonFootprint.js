async function getCarbonFootprint(url) {
  const res = await fetch(`https://api.websitecarbon.com/site?url=${encodeURIComponent(url)}`);
  const data = await res.json();
  return data;
}

getCarbonFootprint('https://yourstore.com').then(data => {
  console.log(`Your site produces ${data.bytes * 0.000000001} metric tons of CO₂ per page view.`);
});