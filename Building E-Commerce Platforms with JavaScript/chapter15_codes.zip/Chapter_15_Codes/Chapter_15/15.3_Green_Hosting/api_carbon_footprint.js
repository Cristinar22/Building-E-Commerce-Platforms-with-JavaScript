// pages/api/carbon-footprint.js
export default async function handler(req, res) {
  const url = 'https://yourstore.com';
  const response = await fetch(`https://api.websitecarbon.com/site?url=${encodeURIComponent(url)}`);
  const data = await response.json();

  res.status(200).json({ co2: data.bytes * 0.000000001 });
}