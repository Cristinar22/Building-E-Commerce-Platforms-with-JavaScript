import { useEffect, useState } from 'react';

export default function CarbonFootprint() {
  const [co2, setCo2] = useState<number|null>(null);

  useEffect(() => {
    fetch('/api/carbon-footprint')
      .then(res => res.json())
      .then(data => setCo2(data.co2));
  }, []);

  if (co2 === null) return <p>Loading carbon footprint data...</p>;

  return (
    <div>
      <p>🌍 Estimated CO₂ emission per page view: {co2.toFixed(4)} metric tons</p>
      <small>Powered by Website Carbon API</small>
    </div>
  );
}