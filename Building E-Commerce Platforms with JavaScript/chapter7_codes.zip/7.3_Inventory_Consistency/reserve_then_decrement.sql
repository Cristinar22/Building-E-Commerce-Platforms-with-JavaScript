-- Reserve items during checkout
UPDATE inventory
SET reserved = reserved + $1
WHERE product_id = $2 AND stock - reserved >= $1;

-- Decrement stock after successful payment
UPDATE inventory
SET stock = stock - $1, reserved = reserved - $1
WHERE product_id = $2;

-- Release reservation after failure/abandonment
UPDATE inventory
SET reserved = reserved - $1
WHERE product_id = $2;