import { trpc } from '../../utils/trpc';

export default function OrdersPage() {
  const { data: orders, isLoading } = trpc.order.all.useQuery();
  const updateStatus = trpc.order.updateStatus.useMutation();

  if (isLoading) return <div>Loading...</div>;

  return (
    <table>
      <thead><tr><th>ID</th><th>Status</th><th>Action</th></tr></thead>
      <tbody>
        {orders?.map(order => (
          <tr key={order.id}>
            <td>{order.id}</td>
            <td>{order.status}</td>
            <td>
              <button onClick={() => updateStatus.mutate({ orderId: order.id, status: 'shipped' })}>
                Mark as Shipped
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}