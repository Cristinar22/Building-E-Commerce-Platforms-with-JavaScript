import { createRouter } from '@trpc/server';
import { z } from 'zod';
import prisma from '../lib/prisma';

export const orderRouter = createRouter()
  .query('all', {
    async resolve() {
      return prisma.order.findMany({ include: { items: true, payment: true, shipment: true } });
    },
  })
  .mutation('updateStatus', {
    input: z.object({ orderId: z.string(), status: z.string() }),
    async resolve({ input }) {
      return prisma.order.update({
        where: { id: input.orderId },
        data: { status: input.status },
      });
    },
  });