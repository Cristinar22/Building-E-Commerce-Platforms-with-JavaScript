const { Worker } = require('bullmq');
const orderQueue = require('./lib/jobs/orderQueue');
const { sendReceiptEmail } = require('./lib/email');

const worker = new Worker('orders', async job => {
  if (job.name === 'send-email') {
    await sendReceiptEmail(job.data.orderId, job.data.userEmail);
  }
}, { connection: { host: 'localhost', port: 6379 } });

console.log('Worker running...');