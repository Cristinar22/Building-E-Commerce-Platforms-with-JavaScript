import { IconButton, HStack, Text } from "@chakra-ui/react";
import { MinusIcon, AddIcon } from "@chakra-ui/icons";
import { useCart } from "../contexts/CartContext";

export function QtyStepper({ id, qty }: { id: string; qty: number }) {
  const { dispatch } = useCart();
  return (
    <HStack>
      <IconButton
        aria-label="Decrease"
        icon={<MinusIcon />}
        onClick={() => dispatch({ type: "SET_QTY", payload: { id, qty: qty - 1 } })}
        isDisabled={qty === 1}
      />
      <Text>{qty}</Text>
      <IconButton
        aria-label="Increase"
        icon={<AddIcon />}
        onClick={() =>
          dispatch({ type: "SET_QTY", payload: { id, qty: qty + 1 } })
        }
      />
    </HStack>
  );
}