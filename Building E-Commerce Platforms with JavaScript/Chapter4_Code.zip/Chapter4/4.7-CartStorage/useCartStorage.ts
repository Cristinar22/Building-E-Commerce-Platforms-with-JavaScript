import { useEffect } from "react";
import { get, set } from "idb-keyval";
import { useCart } from "../contexts/CartContext";

const KEY = "cart-state-v1";

export function useCartStorage() {
  const { state, dispatch } = useCart();

  // Load once on mount
  useEffect(() => {
    get(KEY).then((saved) => {
      if (saved?.length) dispatch({ type: "RESET" }); // clear default []
      saved.forEach((line: any) =>
        dispatch({ type: "ADD", payload: line }) // reuse reducer logic
      );
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Save whenever state changes
  useEffect(() => {
    if (state.length) set(KEY, state);
  }, [state]);
}