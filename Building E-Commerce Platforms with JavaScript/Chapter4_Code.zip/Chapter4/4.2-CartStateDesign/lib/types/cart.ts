export interface CartLineMeta {
  price: number;      // base unit price
  discount: number;   // discount per unit
  tax: number;        // tax per unit
}

export interface CartLine {
  id: string;
  productId: string;
  variantId: string;
  qty: number;
  meta: CartLineMeta;
}

export type CartState = CartLine[];