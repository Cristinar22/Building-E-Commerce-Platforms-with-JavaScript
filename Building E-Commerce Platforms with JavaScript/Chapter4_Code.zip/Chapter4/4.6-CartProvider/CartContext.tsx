import { createContext, useContext, useReducer, ReactNode } from "react";
import { nanoid } from "nanoid";
import type { CartState, CartLine } from "@myorg/types/cart";

type CartAction =
  | { type: "ADD"; payload: Omit<CartLine, "id"> }
  | { type: "REMOVE"; payload: { id: string } }
  | { type: "SET_QTY"; payload: { id: string; qty: number } }
  | { type: "RESET" };

function reducer(state: CartState, action: CartAction): CartState {
  switch (action.type) {
    case "ADD":
      return [...state, { ...action.payload, id: nanoid(8) }];
    case "REMOVE":
      return state.filter((l) => l.id !== action.payload.id);
    case "SET_QTY":
      return state.map((l) =>
        l.id === action.payload.id ? { ...l, qty: action.payload.qty } : l
      );
    case "RESET":
      return [];
    default:
      return state;
  }
}

const CartCtx = createContext<
  | { state: CartState; dispatch: React.Dispatch<CartAction> }
  | undefined
>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(reducer, []);
  return (
    <CartCtx.Provider value={{ state, dispatch }}>{children}</CartCtx.Provider>
  );
}

export const useCart = () => {
  const ctx = useContext(CartCtx);
  if (!ctx) throw new Error("useCart must be within CartProvider");
  return ctx;
};