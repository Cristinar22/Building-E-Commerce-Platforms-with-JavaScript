// packages/ui/src/tokens/palette.ts
export const colors = {
  brand: {
    50:  '#e8edff',
    500: '#1e4aff',   // primary CTA
    700: '#1636bf',
  },
  neutral: {
    50:  '#f9f9fb',
    800: '#2f2f37',
  },
}
