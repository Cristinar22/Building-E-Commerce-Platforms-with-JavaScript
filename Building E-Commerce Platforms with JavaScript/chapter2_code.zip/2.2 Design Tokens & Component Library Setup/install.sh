#!/bin/bash
# Install dependencies
pnpm add @chakra-ui/react @emotion/react @emotion/styled framer-motion
pnpm dlx storybook@latest init
