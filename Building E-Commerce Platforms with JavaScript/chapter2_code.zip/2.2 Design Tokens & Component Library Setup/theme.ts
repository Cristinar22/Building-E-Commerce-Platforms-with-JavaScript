// packages/ui/src/theme/index.ts
import { extendTheme } from "@chakra-ui/react";
import { colors } from "../tokens/palette";

export const theme = extendTheme({
  colors,
  fonts: { heading: "'Inter', sans-serif", body: "'Inter', sans-serif" },
  radii: { md: "0.5rem" },
});
