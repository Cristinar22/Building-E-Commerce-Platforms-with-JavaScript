// hooks/useFilters.ts
import { useState } from "react";

export function useFilters() {
  const [price, setPrice] = useState<[number, number]>([10, 100]);
  const [rating, setRating] = useState(0);
  return { price, setPrice, rating, setRating };
}
