// /pages/product/[slug].tsx
import { Suspense, lazy } from "react";
const Gallery = lazy(() => import("@/components/product/Gallery"));

export default function ProductPage() {
  return (
    <Suspense fallback={<p>Loading images…</p>}>
      <Gallery />
    </Suspense>
  );
}
