// Sticky Add-to-Cart Bar
import { Flex, Text, Button } from "@chakra-ui/react";

export default function StickyAddBar() {
  return (
    <Flex
      position="sticky"
      bottom={0}
      bg="white"
      p={4}
      boxShadow="md"
      justify="space-between"
    >
      <Text fontWeight="bold">$24.00</Text>
      <Button colorScheme="brand">Add to Cart</Button>
    </Flex>
  );
}
