// Hero with Chakra Grid
import { Grid, Box, Heading, Text, Button, Image } from "@chakra-ui/react";

export default function HeroGrid() {
  return (
    <Grid templateColumns={{ base: "1fr", md: "1fr 1fr" }} gap={8}>
      <Box>
        <Heading size="2xl" mb={4}>Feel Good Skin</Heading>
        <Text mb={6}>Plant-based essentials delivered free.</Text>
        <Button size="lg">Shop Now</Button>
      </Box>
      <Image src="/hero.jpg" alt="Smiling woman holding skincare set" />
    </Grid>
  );
}
